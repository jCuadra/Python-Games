Gorman Chess Graphics
Created by Paul Gorman, 2006
http://patzer.paulgorman.org

This archive contains graphics of chess pieces.

I was developing some chess software, and failed to find any chess piece graphics clearly marked as public domain or Creative Commons licensed. So, I made some. This archive contains a complete set of chess pieces as PNG files in three different sizes. It also contains the original Adobe Illustrator file, and an EPS version of the Illustrator file.

These chess image files are licensed under the Creative Commons Attribution 2.5 license. You may use these files as described below. For more information, see http://creativecommons.org/licenses/by/2.5/legalcode.

You are free:

    * to copy, distribute, display, and perform the work
    * to make derivative works
    * to make commercial use of the work

Under the following conditions:
===============================
	
***Attribution***
You must attribute the work in the manner specified by the author or licensor:

    * For any reuse or distribution, you must make clear to others the license terms of this work.
    * Any of these conditions can be waived if you get permission from the copyright holder.
